#ifndef STUDENT_STORE_H
#define STUDENT_STORE_H

#include "slotted_page.h"

int SS_Create(const char *filename);
int SS_Open(const char *filename);
int SS_Close(void);
int SS_Insert(const char *record, SP_RecordID *rid);
int SS_Delete(SP_RecordID rid);
int SS_Scan(void);
int SS_VisitRecords(int (*callback)(const char *, SP_RecordID, void *), void *context);

#endif
