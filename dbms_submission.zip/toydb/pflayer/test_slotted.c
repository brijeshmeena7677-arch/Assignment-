#include <stdio.h>
#include <string.h>
#include "slotted_page.h"

int main()
{
    char page[PF_PAGE_SIZE];
    char output[200];
    int slot1, slot2, slot3;
    int result;

    SP_InitPage(page);

    printf("Initial free space: %d bytes\n",
           SP_FreeSpace(page));

    result = SP_InsertRecord(page,
        "949981;95302001;Student One;M;BTECH",
        36, &slot1);
    printf("Insert record 1: %d, slot: %d\n", result, slot1);

    result = SP_InsertRecord(page,
        "949982;95310001;Student Two;M;BT",
        33, &slot2);
    printf("Insert record 2: %d, slot: %d\n", result, slot2);

    result = SP_InsertRecord(page,
        "949983;95305001;Student Three;M;BTECH",
        38, &slot3);
    printf("Insert record 3: %d, slot: %d\n", result, slot3);

    result = SP_GetRecord(page, slot2, output, sizeof(output));
    if (result > 0) {
        output[result] = '\0';
        printf("Retrieved record 2: %s\n", output);
    }

    printf("Delete record 2: %d\n",
           SP_DeleteRecord(page, slot2));

    printf("Insert after deletion: ");
    result = SP_InsertRecord(page, "New Student Record", 18, &slot2);
    printf("%d, reused slot: %d\n", result, slot2);

    printf("Remaining records: %d\n",
           ((SP_PageHeader *)page)->record_count);

    printf("Free space: %d bytes\n", SP_FreeSpace(page));

    return 0;
}
