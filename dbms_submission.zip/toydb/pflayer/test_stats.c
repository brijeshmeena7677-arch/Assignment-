#include <stdio.h>
#include "pf.h"
#include "pftypes.h"

int main()
{
    int fd, page_no, result;
    char *page;
    PF_Stats stats;

    PF_Init();

    result = PF_CreateFile("stats_test.dat");
    if (result != PFE_OK) {
        printf("Create failed: %d\n", result);
        return 1;
    }

    fd = PF_OpenFile("stats_test.dat");
    if (fd < 0) {
        printf("Open failed: %d\n", fd);
        return 1;
    }

    PF_AllocPage(fd, &page_no, &page);
    PF_UnfixPage(fd, page_no, FALSE);

    /* Flush the page and clear it from the buffer. */
    PF_CloseFile(fd);

    /* Reopen so the page is clean when loaded. */
    fd = PF_OpenFile("stats_test.dat");

    if (fd < 0) {
        printf("Reopen failed: %d\n", fd);
        return 1;
    }

    PF_ResetStats();

    /* First read: physical disk read. */
    PF_GetThisPage(fd, page_no, &page);
    PF_UnfixPage(fd, page_no, FALSE);

    /* Second read: buffer cache hit. */
    PF_GetThisPage(fd, page_no, &page);
    PF_UnfixPage(fd, page_no, FALSE);

    /* Third read and explicit modification. */
    PF_GetThisPage(fd, page_no, &page);
    PF_MarkDirty(fd, page_no);
    PF_UnfixPage(fd, page_no, FALSE);

    PF_GetStats(&stats);

    printf("\nStatistics before closing:\n");
    printf("Logical reads:   %ld\n", stats.logical_reads);
    printf("Logical writes:  %ld\n", stats.logical_writes);
    printf("Physical reads:  %ld\n", stats.physical_reads);
    printf("Physical writes: %ld\n", stats.physical_writes);

    PF_CloseFile(fd);

    PF_GetStats(&stats);

    printf("\nStatistics after closing:\n");
    printf("Logical reads:   %ld\n", stats.logical_reads);
    printf("Logical writes:  %ld\n", stats.logical_writes);
    printf("Physical reads:  %ld\n", stats.physical_reads);
    printf("Physical writes: %ld\n", stats.physical_writes);

    PF_DestroyFile("stats_test.dat");

    return 0;
}
