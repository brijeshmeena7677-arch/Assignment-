#ifndef SLOTTED_PAGE_H
#define SLOTTED_PAGE_H

#include "pf.h"

/* Slotted-page metadata */
#define SP_MAGIC 0x53504C54

typedef struct {
    int magic;
    int slot_count;
    int free_start;
    int free_end;
    int record_count;
} SP_PageHeader;

/* One slot stores the location and length of a record */
typedef struct {
    int offset;
    int length;
} SP_Slot;

/* Record identifier */
typedef struct {
    int page_no;
    int slot_no;
} SP_RecordID;

/* Slotted-page operations */
int SP_InitPage(char *page);
int SP_InsertRecord(char *page, const char *record, int length,
                    int *slot_no);
int SP_DeleteRecord(char *page, int slot_no);
int SP_GetRecord(char *page, int slot_no,
                 char *output, int max_length);
int SP_CompactPage(char *page);
int SP_FreeSpace(char *page);

#endif
