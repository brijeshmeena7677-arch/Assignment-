#include <stdio.h>
#include <string.h>
#include "slotted_page.h"

/* Initialize an empty slotted page */
int SP_InitPage(char *page)
{
    SP_PageHeader *header;

    if (page == NULL)
        return -1;

    memset(page, 0, PF_PAGE_SIZE);

    header = (SP_PageHeader *)page;
    header->magic = SP_MAGIC;
    header->slot_count = 0;
    header->free_start = sizeof(SP_PageHeader);
    header->free_end = PF_PAGE_SIZE;
    header->record_count = 0;

    return 0;
}

/* Return available free space */
int SP_FreeSpace(char *page)
{
    SP_PageHeader *header;

    if (page == NULL)
        return -1;

    header = (SP_PageHeader *)page;

    if (header->magic != SP_MAGIC)
        return -1;

    return header->free_end - header->free_start;
}

/* Compact records toward the end of the page */
int SP_CompactPage(char *page)
{
    SP_PageHeader *header;
    SP_Slot *slots;
    char temporary[PF_PAGE_SIZE];
    int i, destination;

    if (page == NULL)
        return -1;

    header = (SP_PageHeader *)page;

    if (header->magic != SP_MAGIC)
        return -1;

    memset(temporary, 0, sizeof(temporary));
    destination = PF_PAGE_SIZE;

    slots = (SP_Slot *)(page + sizeof(SP_PageHeader));

    for (i = header->slot_count - 1; i >= 0; i--)
    {
        if (slots[i].length > 0)
        {
            destination -= slots[i].length;

            memcpy(temporary + destination,
                   page + slots[i].offset,
                   slots[i].length);

            slots[i].offset = destination;
        }
    }

    memcpy(page + destination, temporary + destination,
           PF_PAGE_SIZE - destination);

    header->free_end = destination;

    return 0;
}

/* Insert a variable-length record */
int SP_InsertRecord(char *page, const char *record,
                    int length, int *slot_no)
{
    SP_PageHeader *header;
    SP_Slot *slots;
    int i, selected_slot;
    int required_space;

    if (page == NULL || record == NULL || length <= 0)
        return -1;

    header = (SP_PageHeader *)page;

    if (header->magic != SP_MAGIC)
        return -1;

    slots = (SP_Slot *)(page + sizeof(SP_PageHeader));

    selected_slot = -1;

    for (i = 0; i < header->slot_count; i++)
    {
        if (slots[i].length == 0)
        {
            selected_slot = i;
            break;
        }
    }

    required_space = length;

    if (selected_slot == -1)
        required_space += sizeof(SP_Slot);

    if (SP_FreeSpace(page) < required_space)
    {
        SP_CompactPage(page);

        if (SP_FreeSpace(page) < required_space)
            return -1;
    }

    if (selected_slot == -1)
    {
        selected_slot = header->slot_count;
        header->slot_count++;
        header->free_start += sizeof(SP_Slot);
    }

    slots = (SP_Slot *)(page + sizeof(SP_PageHeader));

    header->free_end -= length;

    memcpy(page + header->free_end, record, length);

    slots[selected_slot].offset = header->free_end;
    slots[selected_slot].length = length;

    header->record_count++;

    if (slot_no != NULL)
        *slot_no = selected_slot;

    return 0;
}

/* Delete a record using its slot number */
int SP_DeleteRecord(char *page, int slot_no)
{
    SP_PageHeader *header;
    SP_Slot *slots;

    if (page == NULL)
        return -1;

    header = (SP_PageHeader *)page;

    if (header->magic != SP_MAGIC)
        return -1;

    if (slot_no < 0 || slot_no >= header->slot_count)
        return -1;

    slots = (SP_Slot *)(page + sizeof(SP_PageHeader));

    if (slots[slot_no].length == 0)
        return -1;

    slots[slot_no].offset = 0;
    slots[slot_no].length = 0;

    header->record_count--;

    return 0;
}

/* Retrieve a record */
int SP_GetRecord(char *page, int slot_no,
                 char *output, int max_length)
{
    SP_PageHeader *header;
    SP_Slot *slots;

    if (page == NULL || output == NULL)
        return -1;

    header = (SP_PageHeader *)page;

    if (header->magic != SP_MAGIC)
        return -1;

    if (slot_no < 0 || slot_no >= header->slot_count)
        return -1;

    slots = (SP_Slot *)(page + sizeof(SP_PageHeader));

    if (slots[slot_no].length <= 0 ||
        slots[slot_no].length > max_length)
        return -1;

    memcpy(output,
           page + slots[slot_no].offset,
           slots[slot_no].length);

    return slots[slot_no].length;
}
