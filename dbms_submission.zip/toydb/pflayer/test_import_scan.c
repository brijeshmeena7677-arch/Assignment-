#include <stdio.h>
#include "student_store.h"

int main(void)
{
    int count;

    if (SS_Open("student_import.dat") != 0) {
        printf("Database open failed.\n");
        return 1;
    }

    printf("Scanning imported student database...\n");

    count = SS_Scan();

    printf("\nTotal records scanned: %d\n", count);

    SS_Close();

    return count == 17813 ? 0 : 1;
}
