#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student_store.h"

int main(void)
{
    FILE *fp;
    char *line = NULL;
    size_t capacity = 0;
    ssize_t length;
    int inserted = 0;
    int failed = 0;
    SP_RecordID rid;

    fp = fopen("student.txt", "r");

    if (fp == NULL) {
        perror("Cannot open student.txt");
        return 1;
    }

    remove("student_import.dat");

    if (SS_Create("student_import.dat") != 0) {
        printf("Database creation failed.\n");
        fclose(fp);
        return 1;
    }

    if (SS_Open("student_import.dat") != 0) {
        printf("Database opening failed.\n");
        fclose(fp);
        return 1;
    }

    /* Skip the dataset's descriptive first line */
    getline(&line, &capacity, fp);

    while ((length = getline(&line, &capacity, fp)) != -1) {
        while (length > 0 &&
               (line[length - 1] == '\n' ||
                line[length - 1] == '\r')) {
            line[--length] = '\0';
        }

        if (length == 0)
            continue;

        if (SS_Insert(line, &rid) == 0)
            inserted++;
        else
            failed++;
    }

    printf("Student records inserted: %d\n", inserted);
    printf("Failed insertions: %d\n", failed);

    SS_Close();

    free(line);
    fclose(fp);

    return failed == 0 ? 0 : 1;
}
