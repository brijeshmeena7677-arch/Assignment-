#include <stdio.h>
#include <stdlib.h>
#include "pf.h"
#include "pftypes.h"

#define NUM_PAGES 40
#define BUFFER_SIZE 5
#define OPERATIONS 2000

int main()
{
    int percentages[] = {0, 25, 50, 75, 100};
    int test, i, fd, page_no, result;
    int read_percent, is_write;
    int operation_page;
    char *page;
    PF_Stats stats;
    char filename[40];

    PF_Init();

    for (test = 0; test < 5; test++)
    {
        sprintf(filename, "benchmark_%d.dat", test);
        remove(filename);

        result = PF_CreateFile(filename);
        if (result != PFE_OK) {
            printf("Create failed: %d\n", result);
            return 1;
        }

        fd = PF_OpenFile(filename);
        if (fd < 0) {
            printf("Open failed: %d\n", fd);
            return 1;
        }

        /* Create 40 pages. */
        for (i = 0; i < NUM_PAGES; i++) {
            result = PF_AllocPage(fd, &page_no, &page);
            if (result != PFE_OK) {
                printf("Allocation failed: %d\n", result);
                return 1;
            }

            page[0] = (char)i;
            PF_UnfixPage(fd, page_no, FALSE);
        }

        PF_CloseFile(fd);

        /* Reopen to start with an empty buffer. */
        fd = PF_OpenFile(filename);
        if (fd < 0) {
            printf("Reopen failed: %d\n", fd);
            return 1;
        }

        PFbufSetSize(BUFFER_SIZE);
        PF_ResetStats();

        read_percent = 100 - percentages[test];
        srand(12345);

        for (i = 0; i < OPERATIONS; i++) {
            operation_page = rand() % NUM_PAGES;
            is_write = (rand() % 100) >= read_percent;

            result = PF_GetThisPage(fd, operation_page, &page);
            if (result != PFE_OK) {
                printf("Read failed: %d\n", result);
                return 1;
            }

            if (is_write) {
                page[0] = (char)(page[0] + 1);
                PF_UnfixPage(fd, operation_page, TRUE);
            }
            else {
                PF_UnfixPage(fd, operation_page, FALSE);
            }
        }

        PF_CloseFile(fd);

        PF_GetStats(&stats);

        printf("%d%% reads / %d%% writes: "
               "%ld, %ld, %ld, %ld\n",
               read_percent, percentages[test],
               stats.logical_reads,
               stats.logical_writes,
               stats.physical_reads,
               stats.physical_writes);

        PF_DestroyFile(filename);
    }

    return 0;
}
