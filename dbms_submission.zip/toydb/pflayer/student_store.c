#include <stdio.h>
#include <string.h>
#include "student_store.h"

static int SS_fd = -1;
static int SS_last_page = -1;

/* Create a PF file and initialize its first slotted page */
int SS_Create(const char *filename)
{
    int fd, page_no;
    char *page;

    if (PF_CreateFile((char *)filename) != PFE_OK)
        return -1;

    fd = PF_OpenFile((char *)filename);
    if (fd < 0)
        return -1;

    if (PF_AllocPage(fd, &page_no, &page) != PFE_OK) {
        PF_CloseFile(fd);
        return -1;
    }

    SP_InitPage(page);
    PF_MarkDirty(fd, page_no);
    PF_UnfixPage(fd, page_no, FALSE);
    PF_CloseFile(fd);

    return 0;
}

/* Open an existing student file */

int SS_Open(const char *filename)
{
    int result;
    char *page;

    if (SS_fd >= 0)
        return -1;

    SS_fd = PF_OpenFile((char *)filename);

    if (SS_fd < 0)
        return -1;

    SS_last_page = -1;

    result = PF_GetFirstPage(SS_fd, &SS_last_page, &page);

    if (result == PFE_OK) {
        int next_page;

        while (1) {
            next_page = SS_last_page;
            result = PF_GetNextPage(SS_fd, &next_page, &page);

            if (result != PFE_OK)
                break;

            PF_UnfixPage(SS_fd, SS_last_page, FALSE);
            SS_last_page = next_page;
        }

        PF_UnfixPage(SS_fd, SS_last_page, FALSE);
    }

    return 0;
}

/* Close the student file */
int SS_Close(void)
{
    int result;

    if (SS_fd < 0)
        return -1;

    result = PF_CloseFile(SS_fd);
    SS_fd = -1;

    return result;
}

/* Insert a record into the last page, allocating a page when needed */

int SS_Insert(const char *record, SP_RecordID *rid)
{
    int page_no, result, slot_no;
    char *page;

    if (SS_fd < 0 || record == NULL || rid == NULL)
        return -1;

    /* Try inserting into the remembered last page */
    if (SS_last_page >= 0) {
        page_no = SS_last_page;

        result = PF_GetThisPage(SS_fd, page_no, &page);

        if (result == PFE_OK) {
            result = SP_InsertRecord(page, record,
                                     strlen(record), &slot_no);

            if (result == 0) {
                PF_MarkDirty(SS_fd, page_no);
                PF_UnfixPage(SS_fd, page_no, FALSE);

                rid->page_no = page_no;
                rid->slot_no = slot_no;
                return 0;
            }

            PF_UnfixPage(SS_fd, page_no, FALSE);
        }
    }

    /* Allocate a new page when the previous page is full */
    if (PF_AllocPage(SS_fd, &page_no, &page) != PFE_OK)
        return -1;

    SP_InitPage(page);

    result = SP_InsertRecord(page, record, strlen(record), &slot_no);

    if (result != 0) {
        PF_UnfixPage(SS_fd, page_no, FALSE);
        return -1;
    }

    PF_MarkDirty(SS_fd, page_no);
    PF_UnfixPage(SS_fd, page_no, FALSE);

    SS_last_page = page_no;

    rid->page_no = page_no;
    rid->slot_no = slot_no;

    return 0;
}

/* Delete a record by its page and slot identifier */
int SS_Delete(SP_RecordID rid)
{
    char *page;
    int result;

    if (SS_fd < 0)
        return -1;

    result = PF_GetThisPage(SS_fd, rid.page_no, &page);
    if (result != PFE_OK)
        return result;

    result = SP_DeleteRecord(page, rid.slot_no);

    if (result == 0)
        PF_MarkDirty(SS_fd, rid.page_no);

    PF_UnfixPage(SS_fd, rid.page_no, FALSE);

    return result;
}

/* Sequentially scan and print all student records */
int SS_Scan(void)
{
    int page_no, result, slot;
    int count = 0;
    char *page;
    char output[PF_PAGE_SIZE];
    SP_PageHeader *header;

    if (SS_fd < 0)
        return -1;

    result = PF_GetFirstPage(SS_fd, &page_no, &page);

    while (result == PFE_OK) {
        header = (SP_PageHeader *)page;
        if (header->magic == SP_MAGIC) {

            for (slot = 0; slot < header->slot_count; slot++) {
                result = SP_GetRecord(page, slot, output,
                                      sizeof(output) - 1);
                if (result > 0) {
                    output[result] = '\0';
                    printf("%s\n", output);
                    count++;
                }
            }
        }

        PF_UnfixPage(SS_fd, page_no, FALSE);
        result = PF_GetNextPage(SS_fd, &page_no, &page);
    }

    if (result != PFE_EOF)
        return result;

    return count;
}
 

/* Visit each valid student record and provide its physical record ID. */
int SS_VisitRecords(int (*callback)(const char *, SP_RecordID, void *),
                    void *context)
{
    int page_no, result, slot, count = 0;
    char *page;
    char output[PF_PAGE_SIZE];
    SP_PageHeader *header;
    SP_RecordID rid;

    if (SS_fd < 0 || callback == NULL)
        return -1;

    result = PF_GetFirstPage(SS_fd, &page_no, &page);

    while (result == PFE_OK) {
        header = (SP_PageHeader *)page;

        if (header->magic == SP_MAGIC) {
            for (slot = 0; slot < header->slot_count; slot++) {
                result = SP_GetRecord(page, slot, output,
                                      sizeof(output) - 1);

                if (result > 0) {
                    output[result] = '\0';
                    rid.page_no = page_no;
                    rid.slot_no = slot;

                    if (callback(output, rid, context) != 0) {
                        PF_UnfixPage(SS_fd, page_no, FALSE);
                        return -1;
                    }

                    count++;
                }
            }
        }

        PF_UnfixPage(SS_fd, page_no, FALSE);
        result = PF_GetNextPage(SS_fd, &page_no, &page);
    }

    if (result != PFE_EOF)
        return result;

    return count;
}
