#include <stdio.h>
#include "student_store.h"

int main(void)
{
    SP_RecordID id1, id2, id3;
    int count;

    remove("student_test.dat");

    printf("Creating database: %d\n",
           SS_Create("student_test.dat"));

    printf("Opening database: %d\n",
           SS_Open("student_test.dat"));

    printf("Inserting record 1: %d\n",
           SS_Insert("1001;Alice;AI", &id1));

    printf("Inserting record 2: %d\n",
           SS_Insert("1002;Bob;DS", &id2));

    printf("Inserting record 3: %d\n",
           SS_Insert("1003;Charlie;CS", &id3));

    printf("Record 1 location: page %d, slot %d\n",
           id1.page_no, id1.slot_no);

    printf("Deleting record 2: %d\n", SS_Delete(id2));

    printf("\nSequential scan:\n");
    count = SS_Scan();
    printf("Records found: %d\n", count);

    printf("Closing database: %d\n", SS_Close());

    printf("\nReopening database to test persistence:\n");
    printf("Opening database: %d\n",
           SS_Open("student_test.dat"));

    count = SS_Scan();
    printf("Records after reopening: %d\n", count);

    printf("Closing database: %d\n", SS_Close());

    return 0;
}
