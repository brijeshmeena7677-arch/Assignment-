# DBMS Project: PF, Slotted Pages and B+ Tree Indexing

## Overview

This project implements three DBMS components:

1. PF Page Buffering
   - LRU and MRU page replacement.
   - Configurable buffer pool.
   - Dirty-page tracking and explicit dirty marking.
   - Logical and physical I/O statistics.
   - Read/write workload benchmark and graph.

2. Slotted-Page Record Management
   - Variable-length student records.
   - Record insertion, deletion and retrieval.
   - Sequential scanning.
   - Persistent student storage using the PF layer.
   - Space-utilization comparison with fixed-size records.

3. Access Method (AM) B+ Tree Indexing
   - Index creation and insertion.
   - Existing student-file indexing.
   - Repeated insertion from an initially empty database.
   - Sorted-input index construction.
   - Bottom-up bulk loading.
   - Exact-key searches, duplicate-key handling and full index scan.

## Environment

Developed and tested in Google Colab using GCC.

The database page size is 4096 bytes.

The supplied student dataset contains 17,813 records, including three
duplicate roll-number groups.

## Directory structure

- pflayer/: PF layer, slotted-page implementation, student storage,
  tests and PF benchmark.
- amlayer/: B+ tree implementation, index builders, query tests,
  student input and sorted student input.
- README.md: project documentation.

## Build and run

Run commands from the indicated directories.

### 1. Build the PF layer

    cd pflayer
    make

Run the PF regression tests:

    make tests
    rm -f file1 file2
    ./testpf
    ./testhash

Build and run the statistics test:

    gcc -w -o test_stats test_stats.c pflayer.o
    ./test_stats

### 2. Test the slotted-page layer

    gcc -w -o test_slotted test_slotted.c slotted_page.c
    ./test_slotted

Build and run the persistent student-store test:

    gcc -w -o test_student_store test_student_store.c \
        student_store.c slotted_page.c pflayer.o
    ./test_student_store

### 3. Import the student dataset

The input file student.txt is supplied in pflayer/.

    gcc -w -o import_students import_students.c \
        student_store.c slotted_page.c pflayer.o
    ./import_students

Expected result:

    Student records inserted: 17813
    Failed insertions: 0

### 4. Build the AM layer

From pflayer/, build the PF layer first. Then:

    cd ../amlayer
    make -f makefile

The AM object files are used by the student index programs below.

### 5. Build an index from the existing student database

    gcc -w -o student_index student_index.c misc.c \
        am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    ./student_index

This creates the student_existing index using the existing
student_import.dat database.

### 6. Build an index through repeated insertion

    gcc -w -o student_repeated_build student_repeated_build.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    ./student_repeated_build

This starts with an empty student database and inserts records
and index entries one at a time.

### 7. Build an index using sorted input

    gcc -w -o student_sorted_build student_sorted_build.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    ./student_sorted_build

The supplied students_sorted.txt contains the student records
sorted by roll number.

### 8. Perform bottom-up bulk loading

    gcc -w -o student_bulk_load student_bulk_load.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    ./student_bulk_load

This constructs leaf pages from sorted key groups and then
constructs the internal root.

### 9. Run index query tests

Build the query programs using the same AM object files:

    gcc -w -o test_student_query test_student_query.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    gcc -w -o test_student_sorted_query test_student_sorted_query.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    gcc -w -o test_student_bulk_query test_student_bulk_query.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    gcc -w -o test_student_bulk_fullscan test_student_bulk_fullscan.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o

Run the tests after building their corresponding indexes:

    ./test_student_query
    ./test_student_sorted_query
    ./test_student_bulk_query
    ./test_student_bulk_fullscan

The query tests verify numeric and alphanumeric roll numbers,
duplicate roll numbers and the physical record IDs returned
by the index.

The full-scan test checks that all 17,813 index entries can
be traversed.

### 10. Student query performance benchmark

    gcc -w -o benchmark_student_query benchmark_student_query.c \
        misc.c am.o amfns.o amsearch.o aminsert.o amstack.o \
        amglobals.o amscan.o amprint.o \
        ../pflayer/pflayer.o ../pflayer/student_store.c \
        ../pflayer/slotted_page.c

    ./benchmark_student_query

This compares indexed exact-key lookup with a sequential scan.

## Benchmark results

### PF buffer benchmark

The PF benchmark uses 40 pages, a buffer pool of 5 pages and
2,000 operations for each read/write workload.

The measured logical and physical I/O results are saved in:

- pflayer/pf_io_benchmark.csv
- pflayer/pf_io_benchmark.png

### Slotted-page space utilization

The dataset contains 17,813 records.

The packing simulation produced:

- Slotted-page storage: 473 pages.
- Slotted-page payload utilization: 90.79%.
- Fixed 128-byte records: 575 pages, 74.69% payload utilization.
- Fixed 256-byte records: 1,188 pages, 36.15% payload utilization.
- Fixed 512-byte records: 2,545 pages, 16.87% payload utilization.

These are simulated packing comparisons using 4096-byte pages,
not measurements from a separate compiled fixed-record manager.

### B+ tree bottom-up bulk loading

Verified build results:

- Records indexed: 17,813.
- Distinct roll numbers: 17,810.
- Duplicate roll-number groups: 3.
- Leaf pages created: 84.
- Internal root pages created: 1.
- Total index pages created: 85.
- Build time in the recorded run: 0.005433 seconds.

### Query verification

The bottom-up bulk-loaded index passed searches for:

- 95302001: one matching record.
- 96D07001: one matching record.
- 97305818: two matching records.
- 99310001: two matching records.
- 99302001: two matching records.

All returned record IDs passed verification against the student
database. The full index scan returned 17,813 entries.

## Notes

- Run the PF build before building the AM layer.
- Run commands from the specified directories because the programs
  use relative file paths.
- Generated database and index files are created by the build
  programs and are not required in the source submission.
- The benchmark timings are environment-dependent. In particular,
  indexed and sequential query timings can be affected by buffer
  caching.
