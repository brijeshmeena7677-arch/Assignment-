#include <stdio.h>
#include <string.h>
#include <time.h>

#include "am.h"
#include "../pflayer/student_store.h"

#define SOURCE_FILE "student.txt"
#define DATA_FILE "../pflayer/student_repeated.dat"
#define INDEX_NAME "student_repeated"
#define INDEX_NO 0
#define KEY_LENGTH 11
#define RID_FACTOR 512

static int extract_key(const char *record, char key[KEY_LENGTH])
{
    const char *p = strchr(record, ';');
    int length = 0;

    if (!p)
        return -1;

    p++;

    while (*p && *p != ';' && length < KEY_LENGTH)
        key[length++] = *p++;

    if (length == 0 || (*p != ';' && *p != '\0'))
        return -1;

    while (length < KEY_LENGTH)
        key[length++] = '\0';

    return 0;
}

int main(void)
{
    FILE *source;
    char line[4096];
    char key[KEY_LENGTH];
    SP_RecordID rid;

    int index_fd;
    int inserted = 0;
    int failed = 0;
    int line_number = 0;
    int recid;
    int result;

    clock_t start, finish;

    source = fopen(SOURCE_FILE, "r");

    if (!source) {
        printf("Cannot open source file.\n");
        return 1;
    }

    /* Create a completely empty student database. */
    remove(DATA_FILE);
    remove(INDEX_NAME ".0");

    if (SS_Create(DATA_FILE) != 0) {
        printf("Cannot create empty student database.\n");
        fclose(source);
        return 1;
    }

    if (SS_Open(DATA_FILE) != 0) {
        printf("Cannot open student database.\n");
        fclose(source);
        return 1;
    }

    /* Create a new character-key B+ tree index. */
    result = AM_CreateIndex(INDEX_NAME, INDEX_NO, 'c', KEY_LENGTH);

    if (result != AME_OK) {
        printf("Index creation failed: %d\n", result);
        SS_Close();
        fclose(source);
        return 1;
    }

    index_fd = PF_OpenFile(INDEX_NAME ".0");

    if (index_fd < 0) {
        printf("Cannot open index file.\n");
        SS_Close();
        fclose(source);
        return 1;
    }

    start = clock();

    while (fgets(line, sizeof(line), source)) {
        line_number++;

        line[strcspn(line, "\r\n")] = '\0';

        /* Skip the header and empty lines. */
        if (line_number == 1 || line[0] == '\0')
            continue;

        if (extract_key(line, key) != 0) {
            failed++;
            continue;
        }

        /* Insert into the initially empty student database. */
        if (SS_Insert(line, &rid) != 0) {
            failed++;
            continue;
        }

        /* Encode the physical student record ID. */
        recid = rid.page_no * RID_FACTOR + rid.slot_no;

        /* Insert the corresponding key into the B+ tree. */
        result = AM_InsertEntry(index_fd, 'c', KEY_LENGTH,
                                key, recid);

        if (result != AME_OK) {
            printf("Index insertion failed for %s: %d\n",
                   key, result);
            failed++;
            continue;
        }

        inserted++;
    }

    finish = clock();

    fclose(source);
    PF_CloseFile(index_fd);
    SS_Close();

    printf("\nRepeated insertion build results\n");
    printf("---------------------------------\n");
    printf("Records indexed: %d\n", inserted);
    printf("Failed records: %d\n", failed);
    printf("Total processing time: %.6f seconds\n",
           (double)(finish - start) / CLOCKS_PER_SEC);

    return (inserted == 17813 && failed == 0) ? 0 : 1;
}
