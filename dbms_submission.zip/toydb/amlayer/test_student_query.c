#include <stdio.h>
#include <string.h>
#include <time.h>

#include "am.h"
#include "testam.h"
#include "../pflayer/student_store.h"

#define STUDENT_FILE "../pflayer/student_import.dat"
#define INDEX_FILE "student_existing.0"
#define KEY_LENGTH 11
#define RID_FACTOR 512

typedef struct {
    int expected_rid;
    int found;
    int verified;
    const char *expected_roll;
} VerifyContext;

static void make_key(const char *roll, char key[KEY_LENGTH])
{
    int len = (int)strlen(roll);
    memset(key, '\0', KEY_LENGTH);
    if (len > KEY_LENGTH) len = KEY_LENGTH;
    memcpy(key, roll, len);
}

static int verify_record(const char *record, SP_RecordID rid,
                         void *context)
{
    VerifyContext *ctx = (VerifyContext *)context;
    char roll[KEY_LENGTH + 1];
    const char *p = strchr(record, ';');
    int encoded_rid;

    if (!p) return 0;
    p++;

    if (sscanf(p, "%11[^;]", roll) != 1) return 0;

    encoded_rid = rid.page_no * RID_FACTOR + rid.slot_no;

    if (encoded_rid == ctx->expected_rid) {
        ctx->found = 1;
        if (strcmp(roll, ctx->expected_roll) == 0)
            ctx->verified = 1;
    }

    return 0;
}

static int test_search(int index_fd, const char *roll)
{
    char key[KEY_LENGTH];
    int scan_fd, recid, count = 0, first_recid = -1;
    clock_t start, finish;
    PF_Stats stats;
    VerifyContext ctx;

    make_key(roll, key);

    PF_ResetStats();
    start = clock();

    scan_fd = AM_OpenIndexScan(index_fd, 'c', KEY_LENGTH, EQ_OP, key);

    if (scan_fd < 0) {
        printf("Cannot open scan for %s: %d\n", roll, scan_fd);
        return 1;
    }

    recid = AM_FindNextEntry(scan_fd);

    while (recid != AME_EOF) {
        if (count == 0) first_recid = recid;
        count++;
        recid = AM_FindNextEntry(scan_fd);
    }

    finish = clock();
    PF_GetStats(&stats);
    AM_CloseIndexScan(scan_fd);

    printf("\nIndex search: %s\n", roll);
    printf("Matching entries: %d\n", count);
    printf("Search time: %.6f seconds\n",
           (double)(finish - start) / CLOCKS_PER_SEC);
    printf("Index logical reads: %ld\n", stats.logical_reads);
    printf("Index physical reads: %ld\n", stats.physical_reads);

    if (count != 1) return 1;

    ctx.expected_rid = first_recid;
    ctx.found = 0;
    ctx.verified = 0;
    ctx.expected_roll = roll;

    SS_VisitRecords(verify_record, &ctx);

    if (!ctx.found || !ctx.verified) {
        printf("Record verification FAILED: %s\n", roll);
        return 1;
    }

    printf("Record verification: PASSED\n");
    printf("Record ID: %d\n", first_recid);
    return 0;
}

int main(void)
{
    int index_fd;
    int failures = 0;

    if (SS_Open(STUDENT_FILE) != 0) {
        printf("Cannot open student database.\n");
        return 1;
    }

    index_fd = PF_OpenFile(INDEX_FILE);

    if (index_fd < 0) {
        printf("Cannot open index file: %d\n", index_fd);
        SS_Close();
        return 1;
    }

    printf("Testing numeric roll number...\n");
    failures += test_search(index_fd, "95302001");

    printf("\nTesting alphanumeric roll number...\n");
    failures += test_search(index_fd, "96D07001");

    PF_CloseFile(index_fd);
    SS_Close();

    printf("\nQuery test result: %s\n",
           failures == 0 ? "PASSED" : "FAILED");

    return failures == 0 ? 0 : 1;
}
