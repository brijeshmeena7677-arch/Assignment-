#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "am.h"
#include "../pflayer/pf.h"
#include "../pflayer/student_store.h"

#define DATA_FILE "../pflayer/student_sorted.dat"
#define INDEX_NAME "student_bulk"
#define INDEX_FILE "student_bulk.0"
#define KEY_LENGTH 11
#define RID_FACTOR 512

typedef struct {
    char key[KEY_LENGTH];
    int rid;
} Entry;

typedef struct {
    char key[KEY_LENGTH];
    int start;
    int count;
} KeyGroup;

static Entry *entries = NULL;
static KeyGroup *groups = NULL;
static int entry_count = 0;
static int group_count = 0;
static int entry_capacity = 0;

static int collect_record(const char *record, SP_RecordID rid, void *context)
{
    char copy[512];
    char *first;
    char *second;
    Entry *new_entries;

    (void)context;

    if (entry_count == entry_capacity) {
        int new_capacity = entry_capacity ? entry_capacity * 2 : 1024;
        new_entries = realloc(entries, new_capacity * sizeof(Entry));
        if (!new_entries) return -1;
        entries = new_entries;
        entry_capacity = new_capacity;
    }

    snprintf(copy, sizeof(copy), "%s", record);
    first = strchr(copy, ';');
    if (!first) return -1;

    second = first + 1;
    first = strchr(second, ';');
    if (first) *first = '\0';

    if (strlen(second) == 0 || strlen(second) >= KEY_LENGTH)
        return -1;

    memset(entries[entry_count].key, 0, KEY_LENGTH);
    memcpy(entries[entry_count].key, second, strlen(second));

    entries[entry_count].rid = rid.page_no * RID_FACTOR + rid.slot_no;
    entry_count++;
    return 0;
}

static int make_groups(void)
{
    int i;

    groups = calloc(entry_count, sizeof(KeyGroup));
    if (!groups) return -1;

    for (i = 0; i < entry_count; i++) {
        if (i > 0 && memcmp(entries[i - 1].key,
                            entries[i].key, KEY_LENGTH) > 0) {
            fprintf(stderr, "Input records are not sorted by roll number.\n");
            return -1;
        }

        if (i == 0 || memcmp(entries[i - 1].key,
                             entries[i].key, KEY_LENGTH) != 0) {
            memcpy(groups[group_count].key, entries[i].key, KEY_LENGTH);
            groups[group_count].start = i;
            groups[group_count].count = 1;
            group_count++;
        } else {
            groups[group_count - 1].count++;
        }
    }

    return 0;
}

static int write_leaf(int fd, int page_num, int next_page,
                      int first_group, int last_group)
{
    char *page;
    AM_LEAFHEADER header;
    int i, j;
    int key_offset;
    short head;
    short next;
    int rid;
    int recid_offset;
    int err;

    err = PF_GetThisPage(fd, page_num, &page);
    if (err != PFE_OK) { fprintf(stderr, "PF_GetThisPage error %d on page %d\n", err, page_num); return -1; }

    memset(page, 0, PF_PAGE_SIZE);
    memset(&header, 0, sizeof(header));

    header.pageType = 'l';
    header.nextLeafPage = next_page;
    header.recIdPtr = PF_PAGE_SIZE;
    header.keyPtr = AM_sl;
    header.freeListPtr = 0;
    header.numinfreeList = 0;
    header.attrLength = KEY_LENGTH;
    header.numKeys = last_group - first_group;
    header.maxKeys = (PF_PAGE_SIZE - AM_sint - AM_si) /
                     (AM_si + KEY_LENGTH);
    if (header.maxKeys % 2) header.maxKeys--;

    key_offset = AM_sl;

    for (i = first_group; i < last_group; i++) {
        memcpy(page + key_offset, groups[i].key, KEY_LENGTH);

        head = 0;

        /* Build the record-ID linked list for this key. */
        for (j = groups[i].start + groups[i].count - 1;
             j >= groups[i].start; j--) {
            recid_offset = header.recIdPtr - (AM_si + AM_ss);
            if (recid_offset < AM_sl +
                (last_group - first_group) * (KEY_LENGTH + AM_ss)) {
                fprintf(stderr,
                    "Leaf space overlap: page=%d, offset=%d, key-array-end=%d, groups=%d\n",
                    page_num, recid_offset,
                    (int)(AM_sl + (last_group - first_group) * (KEY_LENGTH + AM_ss)),
                    last_group - first_group);
                PF_UnfixPage(fd, page_num, FALSE);
                return -1;
            }

            rid = entries[j].rid;
            next = head;

            memcpy(page + recid_offset, &rid, AM_si);
            memcpy(page + recid_offset + AM_si, &next, AM_ss);

            head = (short)recid_offset;
            header.recIdPtr = (short)recid_offset;
        }

        memcpy(page + key_offset + KEY_LENGTH, &head, AM_ss);
        key_offset += KEY_LENGTH + AM_ss;
    }

    header.keyPtr = (short)key_offset;
    memcpy(page, &header, AM_sl);

    err = PF_UnfixPage(fd, page_num, TRUE);
    if (err != PFE_OK) fprintf(stderr, "PF_UnfixPage error %d on page %d\n", err, page_num);
    return err == PFE_OK ? 0 : -1;
}

int main(void)
{
    int err, fd;
    int root_page;
    char *root_buf;
    int max_internal_keys;
    int leaf_count = 0;
    int *leaf_pages = NULL;
    int *leaf_first_groups = NULL;
    int *leaf_last_groups = NULL;
    int g, start, end, bytes, records;
    int i, child_page;
    int offset;
    int next_page;
    int indexed_records = 0;
    clock_t begin, finish;

    begin = clock();

    if (SS_Open(DATA_FILE) < 0) {
        fprintf(stderr, "Could not open sorted student database.\n");
        return 1;
    }

    if (SS_VisitRecords(collect_record, NULL) < 0) {
        fprintf(stderr, "Could not read student records.\n");
        SS_Close();
        return 1;
    }
    SS_Close();

    if (entry_count == 0 || make_groups() < 0) {
        fprintf(stderr, "No valid sorted records were collected.\n");
        return 1;
    }

    /* Reserve page 1 for the final root. */
    remove(INDEX_FILE);
    err = AM_CreateIndex(INDEX_NAME, 0, 'c', KEY_LENGTH);
    if (err != AME_OK) {
        fprintf(stderr, "AM_CreateIndex failed: %d\n", err);
        return 1;
    }

    err = PF_OpenFile(INDEX_FILE, &fd);
    if (err != PFE_OK) {
        fprintf(stderr, "PF_OpenFile failed: %d\n", err);
        return 1;
    }

    max_internal_keys = (PF_PAGE_SIZE - AM_sint - AM_si) /
                        (AM_si + KEY_LENGTH);
    if (max_internal_keys % 2) max_internal_keys--;

    /* Partition sorted key groups into full leaf pages. */
    leaf_pages = calloc(group_count, sizeof(int));
    leaf_first_groups = calloc(group_count, sizeof(int));
    leaf_last_groups = calloc(group_count, sizeof(int));

    if (!leaf_pages || !leaf_first_groups || !leaf_last_groups) {
        fprintf(stderr, "Memory allocation failed.\n");
        PF_CloseFile(fd);
        return 1;
    }

    g = 0;
    while (g < group_count) {
        start = g;
        bytes = AM_sl;
        records = 0;

        while (g < group_count) {
            int cost = KEY_LENGTH + AM_ss +
                       groups[g].count * (AM_si + AM_ss);

            if (bytes + cost > PF_PAGE_SIZE) break;

            bytes += cost;
            records += groups[g].count;
            g++;
        }

        if (g == start) {
            fprintf(stderr, "A key group cannot fit on an empty leaf.\n");
            PF_CloseFile(fd);
            return 1;
        }

        leaf_first_groups[leaf_count] = start;
        leaf_last_groups[leaf_count] = g;
        leaf_count++;
    }

    if (leaf_count > max_internal_keys + 1) {
        fprintf(stderr,
                "This dataset needs multiple internal levels; "
                "root capacity exceeded.\n");
        PF_CloseFile(fd);
        return 1;
    }

    /* Allocate all leaf pages first so next-leaf links are known. */
    for (i = 0; i < leaf_count; i++) {
        char *unused_page;
        err = PF_AllocPage(fd, &leaf_pages[i], &unused_page);
        if (err != PFE_OK) {
            fprintf(stderr, "PF_AllocPage failed: %d\n", err);
            PF_CloseFile(fd);
            return 1;
        }
        PF_UnfixPage(fd, leaf_pages[i], FALSE);
    }

    /* Construct the leaf level directly, without AM_InsertEntry. */
    for (i = 0; i < leaf_count; i++) {
        next_page = (i + 1 < leaf_count) ? leaf_pages[i + 1] : -1;

        if (write_leaf(fd, leaf_pages[i], next_page,
                       leaf_first_groups[i], leaf_last_groups[i]) < 0) {
            fprintf(stderr, "Failed writing leaf page %d\n", leaf_pages[i]);
            PF_CloseFile(fd);
            return 1;
        }
    }

    /* Construct the root internal page in reserved page 1. */
    err = PF_GetFirstPage(fd, &root_page, &root_buf);
    if (err != PFE_OK) {
        fprintf(stderr, "Could not fetch reserved root page.\n");
        PF_CloseFile(fd);
        return 1;
    }

    memset(root_buf, 0, PF_PAGE_SIZE);

    {
        AM_INTHEADER root_header;
        memset(&root_header, 0, sizeof(root_header));
        root_header.pageType = 'i';
        root_header.numKeys = leaf_count - 1;
        root_header.maxKeys = max_internal_keys;
        root_header.attrLength = KEY_LENGTH;

        memcpy(root_buf, &root_header, AM_sint);

        memcpy(root_buf + AM_sint, &leaf_pages[0], AM_si);

        for (i = 1; i < leaf_count; i++) {
            offset = AM_sint + AM_si +
                     (i - 1) * (KEY_LENGTH + AM_si);

            memcpy(root_buf + offset, groups[leaf_first_groups[i]].key,
                   KEY_LENGTH);

            child_page = leaf_pages[i];
            memcpy(root_buf + offset + KEY_LENGTH, &child_page, AM_si);
        }
    }

    err = PF_UnfixPage(fd, root_page, TRUE);
    if (err != PFE_OK) {
        fprintf(stderr, "Could not save root page.\n");
        PF_CloseFile(fd);
        return 1;
    }

    PF_CloseFile(fd);

    indexed_records = entry_count;
    finish = clock();

    printf("\nBottom-up bulk-load results\n");
    printf("---------------------------\n");
    printf("Records indexed: %d\n", indexed_records);
    printf("Distinct roll numbers: %d\n", group_count);
    printf("Duplicate roll-number groups: %d\n",
           indexed_records - group_count);
    printf("Leaf pages created: %d\n", leaf_count);
    printf("Internal root pages created: 1\n");
    printf("Total index pages created: %d\n", leaf_count + 1);
    printf("Build time: %.6f seconds\n",
           (double)(finish - begin) / CLOCKS_PER_SEC);
    printf("Bulk-load method: bottom-up leaf and root construction\n");

    free(entries);
    free(groups);
    free(leaf_pages);
    free(leaf_first_groups);
    free(leaf_last_groups);

    return 0;
}
