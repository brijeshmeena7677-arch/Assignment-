#include <stdio.h>
#include <string.h>
#include <time.h>

#include "am.h"
#include "testam.h"
#include "../pflayer/student_store.h"

#define STUDENT_FILE "../pflayer/student_sorted.dat"
#define INDEX_FILE "student_bulk.0"
#define KEY_LENGTH 11
#define RID_FACTOR 512
#define MAX_MATCHES 10

typedef struct {
    int recids[MAX_MATCHES];
    int verified[MAX_MATCHES];
    int count;
    const char *expected_roll;
} VerifyContext;

static void make_key(const char *roll, char key[KEY_LENGTH])
{
    int len = (int)strlen(roll);
    memset(key, '\0', KEY_LENGTH);
    if (len > KEY_LENGTH) len = KEY_LENGTH;
    memcpy(key, roll, len);
}

static int verify_record(const char *record, SP_RecordID rid,
                         void *context)
{
    VerifyContext *ctx = (VerifyContext *)context;
    char roll[KEY_LENGTH + 1] = {0};
    const char *p = strchr(record, ';');
    int encoded_rid;
    int i;

    if (!p) return 0;
    p++;

    if (sscanf(p, "%11[^;]", roll) != 1) return 0;

    encoded_rid = rid.page_no * RID_FACTOR + rid.slot_no;

    for (i = 0; i < ctx->count; i++) {
        if (ctx->recids[i] == encoded_rid &&
            strcmp(roll, ctx->expected_roll) == 0) {
            ctx->verified[i] = 1;
        }
    }

    return 0;
}

static int test_search(int index_fd, const char *roll,
                       int expected_count)
{
    char key[KEY_LENGTH];
    int scan_fd, recid;
    int recids[MAX_MATCHES];
    int count = 0;
    int i;
    clock_t start, finish;
    PF_Stats stats;
    VerifyContext ctx;

    make_key(roll, key);

    PF_ResetStats();
    start = clock();

    scan_fd = AM_OpenIndexScan(index_fd, 'c', KEY_LENGTH, EQ_OP, key);

    if (scan_fd < 0) {
        printf("Cannot open scan for %s: %d\n", roll, scan_fd);
        return 1;
    }

    while ((recid = AM_FindNextEntry(scan_fd)) != AME_EOF) {
        if (count < MAX_MATCHES)
            recids[count] = recid;
        count++;
    }

    finish = clock();
    PF_GetStats(&stats);
    AM_CloseIndexScan(scan_fd);

    printf("\nIndex search: %s\n", roll);
    printf("Matching entries: %d\n", count);
    printf("Search time: %.6f seconds\n",
           (double)(finish - start) / CLOCKS_PER_SEC);
    printf("Index logical reads: %ld\n", stats.logical_reads);
    printf("Index physical reads: %ld\n", stats.physical_reads);

    if (count != expected_count || count > MAX_MATCHES) {
        printf("Expected %d matches; got %d\n",
               expected_count, count);
        return 1;
    }

    ctx.count = count;
    ctx.expected_roll = roll;

    for (i = 0; i < count; i++) {
        ctx.recids[i] = recids[i];
        ctx.verified[i] = 0;
    }

    if (SS_VisitRecords(verify_record, &ctx) < 0) {
        printf("Record scan failed.\n");
        return 1;
    }

    for (i = 0; i < count; i++) {
        if (!ctx.verified[i]) {
            printf("Record verification FAILED for ID %d\n",
                   ctx.recids[i]);
            return 1;
        }
    }

    printf("Record verification: PASSED\n");
    for (i = 0; i < count; i++)
        printf("Record ID: %d\n", ctx.recids[i]);

    return 0;
}

int main(void)
{
    int index_fd;
    int failures = 0;

    if (SS_Open(STUDENT_FILE) != 0) {
        printf("Cannot open sorted student database.\n");
        return 1;
    }

    index_fd = PF_OpenFile(INDEX_FILE);

    if (index_fd < 0) {
        printf("Cannot open sorted index: %d\n", index_fd);
        SS_Close();
        return 1;
    }

    printf("Testing unique numeric roll number...\n");
    failures += test_search(index_fd, "95302001", 1);

    printf("\nTesting unique alphanumeric roll number...\n");
    failures += test_search(index_fd, "96D07001", 1);

    printf("\nTesting duplicate roll number 1...\n");
    failures += test_search(index_fd, "97305818", 2);

    printf("\nTesting duplicate roll number 2...\n");
    failures += test_search(index_fd, "99310001", 2);

    printf("\nTesting duplicate roll number 3...\n");
    failures += test_search(index_fd, "99302001", 2);

    PF_CloseFile(index_fd);
    SS_Close();

    printf("\nSorted index query test: %s\n",
           failures == 0 ? "PASSED" : "FAILED");

    return failures == 0 ? 0 : 1;
}
