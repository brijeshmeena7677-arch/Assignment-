#include <stdio.h>
#include <string.h>
#include <time.h>

#include "am.h"
#include "../pflayer/student_store.h"

#define STUDENT_FILE "../pflayer/student_import.dat"
#define INDEX_NAME "student_existing"
#define INDEX_NO 0
#define RID_FACTOR 512
#define KEY_LENGTH 11

extern int AM_CreateIndex(char *, int, char, int);
extern int AM_InsertEntry(int, char, int, char *, int);

typedef struct {
    int index_fd;
    int inserted;
    int failed;
    int parse_failed;
    int rid_failed;
    int am_failed;
} BuildContext;

/* Extract the second semicolon-separated field. */
static int extract_roll(const char *record, char key[KEY_LENGTH])
{
    const char *p;
    int length = 0;

    if (!record || !key)
        return -1;

    p = strchr(record, ';');
    if (!p)
        return -1;

    p++;

    while (*p && *p != ';' && length < KEY_LENGTH) {
        key[length++] = *p++;
    }

    if (length == 0 || (*p != ';' && *p != '\0'))
        return -1;

    while (length < KEY_LENGTH)
        key[length++] = '\0';

    return 0;
}

static int index_student(const char *record, SP_RecordID rid,
                         void *context)
{
    BuildContext *ctx = (BuildContext *)context;
    char key[KEY_LENGTH];
    int recid, result;

    if (extract_roll(record, key) != 0) {
        ctx->failed++;
        ctx->parse_failed++;
        return 0;
    }

    if (rid.slot_no < 0 || rid.slot_no >= RID_FACTOR ||
        rid.page_no < 0 ||
        rid.page_no > (2147483647 - rid.slot_no) / RID_FACTOR) {
        ctx->failed++;
        ctx->rid_failed++;
        return 0;
    }

    recid = rid.page_no * RID_FACTOR + rid.slot_no;

    result = AM_InsertEntry(ctx->index_fd, 'c', KEY_LENGTH,
                            key, recid);

    if (result != AME_OK) {
        ctx->failed++;
        ctx->am_failed++;
        if (ctx->am_failed <= 10)
            printf("AM insertion failed: key=%s recid=%d error=%d\n",
                   key, recid, result);
        return 0;
    }

    ctx->inserted++;
    return 0;
}

int main(void)
{
    BuildContext ctx = {0};
    int result;
    clock_t start, finish;
    char filename[100];

    if (SS_Open(STUDENT_FILE) != 0) {
        printf("Cannot open student database.\n");
        return 1;
    }

    result = AM_CreateIndex(INDEX_NAME, INDEX_NO, 'c', KEY_LENGTH);

    if (result != AME_OK) {
        printf("Cannot create index: %d\n", result);
        SS_Close();
        return 1;
    }

    sprintf(filename, "%s.%d", INDEX_NAME, INDEX_NO);
    ctx.index_fd = PF_OpenFile(filename);

    if (ctx.index_fd < 0) {
        printf("Cannot open index file.\n");
        SS_Close();
        return 1;
    }

    start = clock();
    result = SS_VisitRecords(index_student, &ctx);
    finish = clock();

    PF_CloseFile(ctx.index_fd);
    SS_Close();

    printf("\nStudent index build results\n");
    printf("---------------------------\n");
    printf("Records visited: %d\n", result);
    printf("Entries inserted: %d\n", ctx.inserted);
    printf("Records skipped: %d\n", ctx.failed);
    printf("Roll parsing failures: %d\n", ctx.parse_failed);
    printf("Record ID failures: %d\n", ctx.rid_failed);
    printf("AM insertion failures: %d\n", ctx.am_failed);
    printf("Build time: %.6f seconds\n",
           (double)(finish - start) / CLOCKS_PER_SEC);

    return (ctx.failed == 0 && result == ctx.inserted) ? 0 : 1;
}
