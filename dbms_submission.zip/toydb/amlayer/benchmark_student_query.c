#include <stdio.h>
#include <string.h>
#include <time.h>

#include "am.h"
#include "testam.h"
#include "../pflayer/student_store.h"

#define STUDENT_FILE "../pflayer/student_sorted.dat"
#define INDEX_FILE "student_sorted.0"
#define KEY_LENGTH 11

static const char *target = "99M05601";

typedef struct {
    int matches;
} ScanContext;

static void make_key(const char *roll, char key[KEY_LENGTH])
{
    memset(key, 0, KEY_LENGTH);
    memcpy(key, roll, strlen(roll) < KEY_LENGTH ?
           strlen(roll) : KEY_LENGTH);
}

static int scan_callback(const char *record, SP_RecordID rid,
                         void *context)
{
    ScanContext *ctx = (ScanContext *)context;
    const char *p = strchr(record, ';');
    char roll[KEY_LENGTH + 1] = {0};

    (void)rid;

    if (p) {
        p++;
        if (sscanf(p, "%11[^;]", roll) == 1 &&
            strcmp(roll, target) == 0) {
            ctx->matches++;
        }
    }

    return 0;
}

static int indexed_search(int index_fd, int *matches)
{
    char key[KEY_LENGTH];
    int scan_fd, recid;

    make_key(target, key);
    *matches = 0;

    scan_fd = AM_OpenIndexScan(index_fd, 'c', KEY_LENGTH, EQ_OP, key);

    if (scan_fd < 0)
        return -1;

    while ((recid = AM_FindNextEntry(scan_fd)) != AME_EOF)
        (*matches)++;

    AM_CloseIndexScan(scan_fd);
    return 0;
}

int main(void)
{
    int index_fd;
    int index_matches = 0;
    int sequential_records;
    ScanContext context;

    clock_t start, finish;
    double index_time, sequential_time;
    PF_Stats index_stats, sequential_stats;

    if (SS_Open(STUDENT_FILE) != 0) {
        printf("Cannot open student database.\n");
        return 1;
    }

    index_fd = PF_OpenFile(INDEX_FILE);

    if (index_fd < 0) {
        printf("Cannot open index.\n");
        SS_Close();
        return 1;
    }

    /* Warm up the index before measuring. */
    if (indexed_search(index_fd, &index_matches) != 0) {
        printf("Index warm-up failed.\n");
        return 1;
    }

    /* Measure indexed search. */
    PF_ResetStats();
    start = clock();

    if (indexed_search(index_fd, &index_matches) != 0) {
        printf("Index search failed.\n");
        return 1;
    }

    finish = clock();
    index_time = (double)(finish - start) / CLOCKS_PER_SEC;
    PF_GetStats(&index_stats);

    /* Measure full sequential scan. */
    context.matches = 0;
    PF_ResetStats();
    start = clock();

    sequential_records = SS_VisitRecords(scan_callback, &context);

    finish = clock();
    sequential_time = (double)(finish - start) / CLOCKS_PER_SEC;
    PF_GetStats(&sequential_stats);

    printf("\nStudent query performance comparison\n");
    printf("------------------------------------\n");
    printf("Search key: %s\n", target);

    printf("\nB+ tree indexed search:\n");
    printf("Matching records: %d\n", index_matches);
    printf("Time: %.6f seconds\n", index_time);
    printf("Logical page accesses: %ld\n",
           index_stats.logical_reads);
    printf("Physical page reads: %ld\n",
           index_stats.physical_reads);

    printf("\nSequential scan:\n");
    printf("Records visited: %d\n", sequential_records);
    printf("Matching records: %d\n", context.matches);
    printf("Time: %.6f seconds\n", sequential_time);
    printf("Logical page accesses: %ld\n",
           sequential_stats.logical_reads);
    printf("Physical page reads: %ld\n",
           sequential_stats.physical_reads);

    printf("\nComparison result: %s\n",
           index_matches == context.matches &&
           sequential_records == 17813 ? "PASSED" : "FAILED");

    PF_CloseFile(index_fd);
    SS_Close();

    return 0;
}
