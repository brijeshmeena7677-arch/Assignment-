#include <stdio.h>
#include <stdlib.h>
#include "am.h"
#include "testam.h"
#include "../pflayer/pf.h"

#define INDEX_FILE "student_bulk.0"
#define EXPECTED_ENTRIES 17813

int main(void)
{
    int fd, scan, rid, count = 0;
    int status;

    fd = PF_OpenFile(INDEX_FILE);
    if (fd < 0) {
        printf("Cannot open bulk index\n");
        return 1;
    }

    scan = AM_OpenIndexScan(fd, 'c', 11, EQ_OP, NULL);
    if (scan < 0) {
        printf("Cannot open full index scan: %d\n", scan);
        PF_CloseFile(fd);
        return 1;
    }

    while ((rid = AM_FindNextEntry(scan)) != AME_EOF) {
        if (rid < 0) {
            printf("Scan error: %d\n", rid);
            AM_CloseIndexScan(scan);
            PF_CloseFile(fd);
            return 1;
        }
        count++;
    }

    status = AM_CloseIndexScan(scan);
    PF_CloseFile(fd);

    printf("Bulk index full-scan results\n");
    printf("----------------------------\n");
    printf("Expected entries: %d\n", EXPECTED_ENTRIES);
    printf("Entries scanned:  %d\n", count);
    printf("Scan result:      %s\n",
           count == EXPECTED_ENTRIES && status >= 0 ? "PASSED" : "FAILED");

    return (count == EXPECTED_ENTRIES && status >= 0) ? 0 : 1;
}
